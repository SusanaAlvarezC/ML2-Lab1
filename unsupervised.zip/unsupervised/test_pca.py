from unsupervised.pca import PCA
import numpy as np

# Generar algunos datos de prueba
np.random.seed(42)
data = np.random.rand(10, 5)

# Crear una instancia de PCA y ajustar los datos
pca = PCA(n_components=2)
transformed_data=pca.fit(data)

print("Original Data:")
print(data)
print("\nTransformed Data:")
print(transformed_data)

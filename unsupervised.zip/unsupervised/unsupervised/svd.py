import numpy as np

class SVD:
    def __init__(self, n_components):
        self.n_components = n_components
        self.U = None
        self.Sigma = None
        self.Vt = None

    def fit(self, X):
        # Perform SVD
        self.U, self.Sigma, self.Vt = np.linalg.svd(X, full_matrices=False)        

        # Keep only the first n_components
        self.U = self.U[:, :self.n_components]
        self.Sigma = np.diag(self.Sigma[:self.n_components])
        self.Vt = self.Vt[:self.n_components, :]
        
    def fit_transform(self, X):
        self.fit(X)
        return np.dot(self.U, np.dot(self.Sigma, self.Vt))

    def transform(self, X):        
        return np.dot(X, np.dot(self.Vt.T, self.Vt))

    def calculate_mse(original, approx):
        return np.mean((original - approx) ** 2)
    

    
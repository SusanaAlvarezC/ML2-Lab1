from unsupervised.svd import SVD
import numpy as np

def test_svd():
    # Datos de prueba
    data = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

    # Crear una instancia de SVD con 2 componentes
    svd = SVD(n_components=2)

    # Ajustar los datos a la descomposición SVD
    svd.fit(data)

    # Transformar los datos
    transformed_data = svd.transform(data)

    # Imprimir resultados
    print("Original Data:")
    print(data)
    print("\nTransformed Data:")
    print(transformed_data)

if __name__ == "__main__":
    test_svd()
